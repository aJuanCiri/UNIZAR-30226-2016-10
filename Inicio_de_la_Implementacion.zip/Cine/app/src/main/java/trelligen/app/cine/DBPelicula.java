package trelligen.app.cine;

/**
 * Encapsula las consultas y funciones necesarias para la gestión de la base de datos de películas
 */
public class DBPelicula {
    private GestorDB gestordb;
    private Pelicula pelicula;

    public DBPelicula(){
        gestordb = new GestorDB();
    }

    public Pelicula getInformacion(int id){
        //String consulta = "SELECT ...";
        //ResultadosConsulta resultado = gestordb.hacerConsulta(consulta);
        //(ResultadosConsulta es una hipotética clase que gestiona los resultados de las consultas sql)
        //pelicula = new Pelicula(...);
        //return pelicula;
        return null;
    }

    //...
}
