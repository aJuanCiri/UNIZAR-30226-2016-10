package trelligen.app.cine;

import java.util.ArrayList;

/**
 * La clase encapsula una serie de funciones, que realizan operaciones de lectura y escritura
 * a la parte interna del sistema, trata información de los usuarios, películas, colecciones,...
 */
public class Sistema {
    private DBUsuario dbusuario;
    private DBPelicula dbpelicula;
    private Usuario usuario;

    public Sistema(){
        dbusuario = new DBUsuario();
        dbpelicula = new DBPelicula();
    }
    public boolean login (String mail, String password){
        boolean loginOK =  dbusuario.checkLogin(mail,password);
        if (loginOK){
            // iniciar la sesión
            usuario = dbusuario.getInfo(mail); //Cargar en memoria la información del usuario
        }
        return loginOK;
    }

    public boolean borrarPelicula(int id){
        return false;
    }

    public ArrayList<Pelicula> listarPeliculas(){
        return null;
    }

    public ArrayList<Pelicula> buscarPeliculas(String titulo, int fecha, String categoria, String publico, int valoracion){
        return null;
    }

    public boolean eliminarUsuario(String mail){
        return false;
    }

    public boolean cerrarSesion(){
        return false;
    }

    public Pelicula getPelicula(int id){
        return null;
    }

    public boolean nuevaPelicula(String titulo, String fecha, String sinopsis, String duracion, double valoracion){
        return false;
    }

    public boolean newUser(String mail, String pass, String nick, String nacimiento){
        return false;
    }

    //... Se pueden implementar todas las que hagan falta, Sistema actúa como interface de cara al exterior, toda la información
    //debe pasar por aquí.
}
