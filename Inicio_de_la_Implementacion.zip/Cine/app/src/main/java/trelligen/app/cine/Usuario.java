package trelligen.app.cine;

/**
 * Encapsula toda la información sobre un usuario
 */
public class Usuario {
    private String email;
    private String nick;
    private String fecha_nacimiento;

    public Usuario(){

    }

    public String getMail(){
        return null;
    }

    //...
}
