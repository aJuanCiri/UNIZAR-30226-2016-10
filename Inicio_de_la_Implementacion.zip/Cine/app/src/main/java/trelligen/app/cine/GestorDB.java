package trelligen.app.cine;

/**
 * Conecta con la base de datos, realiza consultas o modificaciones, y devuelve resultados
 */
public class GestorDB {
    //...
    //Aqui va lo relacionado con Oracle, fuera de aquí no se tiene que hacer mención a Oracle, se puede
    //poner codigo SQL, pero no cuestiónes de conectividad y demás, de esa forma se puede cambiar con
    //facilidad en el futuro de sistema gestor de base de datos.
}
