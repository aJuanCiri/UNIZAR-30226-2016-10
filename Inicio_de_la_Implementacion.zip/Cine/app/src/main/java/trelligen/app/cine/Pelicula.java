package trelligen.app.cine;

/**
 * Encapsula toda la información sobre una película
 */
public class Pelicula {
    private int id;
    private String titulo;
    private int fecha;
    private String sinopsis;
    private int duración;
    private double valoración;
    private String categoria;
    private String publico;

    public Pelicula(){

    }

    public String getTitulo(){
        return titulo;
    }

    //...
}
